CREATE PROCEDURE update_data_history_slaveIndex(IN startPosition INT, IN perRecored INT)
  begin 
    declare startIndex int default startPosition;
    declare endIndex int default perRecored;
    
        update 
            iot_data_history dh, (select ds.device_id, dt2data.dataid, ds.slave_index from iot_device_slave ds 
join iot_dt2data dt2data on ds.data_template_id = dt2data.template_id) cmd
        set 
            dh.slave_index = cmd.slave_index  
        where 
            dh.did = cmd.device_id and dh.dataid = cmd.dataid and dh.id BETWEEN startIndex and endIndex;
    
end;
